import React from 'react';
import ReactDOM from 'react-dom/client';

//show some kind of not foud this page message for any other pages

export default function Main(){
    return (
        <h1>The page you are looking for is not found.</h1>
        
        )
    }