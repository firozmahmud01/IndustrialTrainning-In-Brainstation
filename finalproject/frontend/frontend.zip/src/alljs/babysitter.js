import React from 'react';
import ReactDOM from 'react-dom/client';


export default function Main(){
    return (
        <h1>Baby Sitter</h1>
        
        )
    }
